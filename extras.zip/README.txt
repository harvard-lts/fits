This ZIP file contains a patch for FITS 0.4.2 and sample XSLT files for
converting the FITS xml output format to PREMIS. These were contributed 
by Swithun Crowe, whose notes are below. 

----------------------------------------------------------------------------

I've attached a patch for a few of the things mentioned above. Most of
the changes/additions are in OISConsolidator.java, although each of
the .xslt files that are used have an xsl:param added.

With the fields which can contain the size of the file being checked,
if one of them contains a real number (e.g. 32204), but another one
contains a string (e.g. 31kB), then what happens now is that these
values can be considered equivalent. There has to be at least one real
number among the size elements, and there has to be less than one unit
more/less than the number of bytes in order for an element containing
a number and units to be considered equivalent.

The advantage of this is that there should be fewer SINGLE_RESULTs in
the output.

For fields which contain timestamps (e.g. created and lastmodified),
the tools will output timestamps in different formats. These could be
processed in XSLT to a certain extent. But I thought it would be
better to do all this in Java. Now timestamps can be converted into
Date objects and these can be compared. And when outputting
timestamps, FITS can be configured to use different formats.

The advantage of this is that different tools using different
timestamp formats can now agree, rather than produce conflicting
output. And also, FITS can produce output suitable for different tools
which process FITS output. This means that the timestamps that FITS
outputs will be in a constant format, rather than the format of the
first tool that identifies the file.

I've used Exiftool version 8.25. The directory layout is slightly
different (hence the path to the Perl script is different), but it
works just like the older version that ships with FITS 0.4.2. The
reason for getting a newer version is that it has better support for
outputting timestamps in a given format (hence the extra arguments for
calling exiftool).

Looking at the source for Jhove 1.5, I see that it actually converts
its timestamps into a non-standard format (a : between the hours and
minutes in the time zone field). I'm correcting this in XSLT, so that
the Java code can read them as valid timestamps.

So that the XSLT scripts only produce extra output if desired, I've
added a xsl:param which is only set if you call FITS with a -r switch.
If you don't, and with the right settings in fits.xml, the output
should be the same as without the changes in the patch.

I would find these changes useful as it makes the output from FITS
more robust. There will be fewer false CONFLICTs and SINGLE_RESULTs,
meaning the ones remaining are more likely to be genuine and worthy of
human/machine investigation. And the timestamps will be in a single
constant format, which will help other tools accept FITS output (e.g.
using XSLT to convert it into valid PREMIS).

What do people think?

----------------------------------------------------------------------------

Hello

I've developed a couple of XSLT stylesheets for transforming FITS
output into Premis XML. These produce Premis Object and Event
documents. The Object document contains most of the information about
the file that FITS has processed, and the Event document contains
information about having run FITS on the file.

I've attached the XSLT documents, in case anyone would find them useful.

They are probably not complete, as I have only tested them with FITS
output from a few sample files. But they cover the bits of Premis that
match our needs (we don't need metadata on encryption, digital
signatures and complex relationships, for example).

They require some external parameters to be passed during the
transformation, for things that FITS doesn't necessarily know. I
imagine using these stylesheets inside the Alfresco CMS, where the
Premis documents will help make up part of METS documents that can be
then fed into Fedora Commons.

If I use my patched version of FITS, then the resulting Premis
documents are valid according to the schema. Without my patch for
standardising timestamps, the documents are not valid.

Last week I posted a question on some mailing lists about expressing
levels of certainty in Premis - i.e. how to translate CONFLICT and
SINGLE_RESULT attributes into Premis. For conflicting values, Premis
usually allows repeatable fields, but currently that is all. But it is
something that they are thinking about.

Swithun.

-----------------------------------------------------------------------------
